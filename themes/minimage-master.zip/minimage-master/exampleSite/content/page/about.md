+++
title = "About Hugo"
date = "2014-04-09"
menu = "main"
+++

Hugo is a static site engine written in Go.


It makes use of a variety of open source projects including:

* [Cobra](https://github.com/spf13/cobra)
* [Viper](https://github.com/spf13/viper)
* [J Walter Weatherman](https://github.com/spf13/jWalterWeatherman)
* [Cast](https://github.com/spf13/cast)

Learn more and contribute on [GitHub](https://github.com/gohugoio).

